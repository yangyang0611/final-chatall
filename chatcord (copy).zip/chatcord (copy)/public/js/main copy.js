const chatForm = document.getElementById('chat-form');
const chatMessages = document.querySelector('.chat-messages');
const roomName = document.getElementById('room-name');
const userList = document.getElementById('users');
const roomSelect = document.getElementById('room');
const customRoomInput = document.getElementById('custom-room');

// Get username and room from URL
const { username, room, customRoom } = Qs.parse(location.search, {
  ignoreQueryPrefix: true,
});

// Update the room name in the HTML
roomName.innerText = room !== 'Custom' ? room : customRoom;

const socket = io();

// Join chatroom
socket.emit('joinRoom', { username, room });

// Get room and users
socket.on('roomUsers', ({ room, users }) => {
  outputRoomName(room);
  outputUsers(users);
});

// Message from server
socket.on('message', (message) => {
  console.log(message);
  outputMessage(message);

  // Scroll down
  chatMessages.scrollTop = chatMessages.scrollHeight;
});

// Message submit
chatForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // Get message text
  let msg = e.target.elements.msg.value;

  msg = msg.trim();

  if (!msg) {
    return false;
  }

  // Emit message to server
  socket.emit('chatMessage', msg);

  // Clear input
  e.target.elements.msg.value = '';
  e.target.elements.msg.focus();
});

// Update the room list on the client side
socket.on('updateRoomList', (rooms) => {
  const roomListElement = document.getElementById('room-list');
  roomListElement.innerHTML = '';

  rooms.forEach((room) => {
    const optionElement = document.createElement('option');
    optionElement.value = room;
    optionElement.textContent = room;
    roomListElement.appendChild(optionElement);
  });

  // If the custom room exists, select it in the dropdown
  if (customRoom && rooms.includes(customRoom)) {
    roomListElement.value = customRoom;
  }
});

// Listen for changes in the room select dropdown
roomSelect.addEventListener('change', () => {
  if (roomSelect.value === 'Custom') {
    customRoomInput.disabled = false;
  } else {
    customRoomInput.disabled = true;
    customRoomInput.value = '';
  }
});

// Submit the form
chatForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // Get message text
  let msg = e.target.elements.msg.value;

  msg = msg.trim();

  if (!msg) {
    return false;
  }

  // Get the selected room value
  const selectedRoom = roomSelect.value;

  // Check if a custom room is selected and the input is not empty
  if (selectedRoom === 'Custom') {
    const customRoomValue = customRoomInput.value.trim();
    if (customRoomValue !== '') {
      // Emit the custom room name to the server
      socket.emit('joinRoom', { username, room: customRoomValue });
    }
  } else {
    // Emit the selected room to the server
    socket.emit('joinRoom', { username, room: selectedRoom });
  }

  // Emit message to server
  socket.emit('chatMessage', msg);

  // Clear input
  e.target.elements.msg.value = '';
  e.target.elements.msg.focus();
});


// Output message to DOM
function outputMessage(message) {
  const div = document.createElement('div');
  div.classList.add('message');
  const p = document.createElement('p');
  p.classList.add('meta');
  p.innerText = message.username;
  p.innerHTML += `<span>${message.time}</span>`;
  div.appendChild(p);
  const para = document.createElement('p');
  para.classList.add('text');
  para.innerText = message.text;
  div.appendChild(para);
  document.querySelector('.chat-messages').appendChild(div);
}

// Add room name to DOM
function outputRoomName(room) {
  roomName.innerText = room;
}

// Add users to DOM
function outputUsers(users) {
  userList.innerHTML = '';
  users.forEach((user) => {
    const li = document.createElement('li');
    li.innerText = user.username;
    userList.appendChild(li);
  });
}

// Prompt the user before leaving the chat room
document.getElementById('leave-btn').addEventListener('click', () => {
  const leaveRoom = confirm('Are you sure you want to leave the chatroom?');
  if (leaveRoom) {
    window.location = '../index.html';
  }
});
